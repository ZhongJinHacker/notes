### 整个项目采用MVC 框架开发

#### view/option_view.py 代表 在命令行中展现的样式
#### controller/version_controller 为执行层，做参数的检查 及调用服务
#### service/version_service 为实现层，内部为真正的实现逻辑
#### config/db_config 为配置模块，实现读取外部（resources目录中）配置

#### 一共实现三个功能
##### 初始化版本 init
##### 升级到版本 upgrade
##### 回滚到版本 rollback
#### 具体实现在version_service中

#### resources 目录内容介绍
```
config/db_config.json
内部记录着 每个数据库连接的配置（host account password等）

version
记录着每次迭代版本的目录（比如1.0 是第一个版本 ，2.0 是第二次发版的版本 等等）

1.0 or 2.0 ...
其内部有三个目录 init rollback update （三个目录名称固定）

init
init 目录为当前版本的全量sql（用于直接初始化到该版本）

update 目录为 当已初始化后，执行升级到某个版本，sql为增量sql
比如 1.0 -> 4.0 会执行 2.0， 3.0，4.0 update目录下的sql

rollback 目录为 当初始化以后，回滚到某个版本，sql为回滚sql
比如 4.0 -> 1.0 会执行 4.0， 3.0， 2.0 update目录下的sql

支持多个项目数据源同时执行
在init rollback update 项目下创建 项目目录 项目目录下防止对应的SQL文件

其中项目目录名 需要与 config/db_config.json 中的key名一致
```

#### 当前记录初始化到版本的方法 是创建并写文件 resources/db_version.txt
#### 后期建议写到数据库中

#### 执行方法
```
初始化到版本
python fs_db_ctl_app.py --init version_code     
e.g. python fs_db_ctl_app.py --init 1.0

升级到版本
python fs_db_ctl_app.py --upgrade version_code  
e.g. python fs_db_ctl_app.py --upgrade 3.0

回滚到版本
python fs_db_ctl_app.py --rollback version_code 
e.g. python fs_db_ctl_app.py --rollback 2.0
```



CREATE TABLE `test_openmics_table1` (
  `id` int(32) NOT NULL AUTO_INCREMENT,
  `account` varchar(255) DEFAULT NULL,
  `company` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE `test_openmics_table2` (
  `id` int(32) NOT NULL AUTO_INCREMENT,
  `account` varchar(255) DEFAULT NULL,
  `company` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `test_openmics_table1`(`account`, `company`)
VALUES ('openmics_table1_user1', '1001');
INSERT INTO `test_openmics_table1`(`account`, `company`)
VALUES ('openmics_table1_user2', '1001');

INSERT INTO `test_openmics_table2`(`account`, `company`)
VALUES ('openmics_table2_user1', '1002');
INSERT INTO `test_openmics_table2`(`account`, `company`)
VALUES ('openmics_table2_user2', '1002');



CREATE TABLE `test_openmics_table3` (
  `id` int(32) NOT NULL AUTO_INCREMENT,
  `account` varchar(255) DEFAULT NULL,
  `company` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `test_openmics_table3`(`account`, `company`)
VALUES ('openmics_table3_user1', '1003');
INSERT INTO `test_openmics_table3`(`account`, `company`)
VALUES ('openmics_table3_user2', '1003');









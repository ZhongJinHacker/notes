INSERT INTO `test_openmics_table3`(`account`, `company`)
VALUES ('openmics_table3_user1', '1003');
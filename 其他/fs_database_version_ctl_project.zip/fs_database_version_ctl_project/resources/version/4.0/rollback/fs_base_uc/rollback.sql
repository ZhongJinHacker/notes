INSERT INTO `test_uc_table3`(`account`, `company`)
VALUES ('uc_table3_user1', '1003');
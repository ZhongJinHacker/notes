
DELETE FROM `test_openmics_table3` WHERE account = 'openmics_table3_user1';
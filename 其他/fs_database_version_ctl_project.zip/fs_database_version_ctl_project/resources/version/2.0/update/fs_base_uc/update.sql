INSERT INTO `test_uc_table1`(`account`, `company`)
VALUES ('uc_table1_user2_v2', '1001');

INSERT INTO `test_uc_table2`(`account`, `company`)
VALUES ('uc_table2_user1_v2', '1002');
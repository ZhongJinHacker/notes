INSERT INTO `test_openmics_table1`(`account`, `company`)
VALUES ('openmics_table1_user1_v2', '1001');

INSERT INTO `test_openmics_table2`(`account`, `company`)
VALUES ('openmics_table2_user1_v2', '1002');
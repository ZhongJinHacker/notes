DELETE FROM `test_openmics_table1` where account = 'openmics_table1_user1_v2';
DELETE FROM `test_openmics_table2` where account = 'openmics_table2_user1_v2';

DELETE FROM `test_uc_table1` where account = 'uc_table1_user2_v2';
DELETE FROM `test_uc_table2` where account = 'uc_table2_user1_v2';
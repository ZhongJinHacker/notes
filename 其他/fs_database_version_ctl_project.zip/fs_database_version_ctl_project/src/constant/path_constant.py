# -*-coding:utf-8-*-
"""
@author:jiangzhongjin
"""

import os

_CUR_DIR_PATH = os.path.dirname(os.path.realpath(__file__))

"""
资源目录
"""
RESOURCES_PATH = _CUR_DIR_PATH + os.sep + '..' + os.sep + '..' + os.sep + 'resources'

"""
资源config目录
"""
RESOURCES_CONFIG_PATH = RESOURCES_PATH + os.sep + 'config'


"""
资源db_config.json 路径
"""
DB_CONFIG_PATH = RESOURCES_CONFIG_PATH + os.sep + 'db_config.json'

"""
资源sql目录
"""
RESOURCES_VERSION_DIR_PATH = RESOURCES_PATH + os.sep + 'version'

"""
资源版本文件路径
"""
RESOURCE_VERSION_PATH = RESOURCES_PATH + os.sep + 'db_version.txt'



if __name__ == '__main__':
    print(RESOURCES_PATH)
    print(os.listdir(RESOURCES_PATH))

    print(RESOURCES_CONFIG_PATH)
    print(os.listdir(RESOURCES_CONFIG_PATH))

    print(RESOURCES_VERSION_DIR_PATH)
    print(os.listdir(RESOURCES_VERSION_DIR_PATH))


# -*-coding:utf-8-*-
"""
@author:jiangzhongjin
"""
import pymysql


class DbConnector:

    def __init__(self, config):
        # 打开数据库连接
        self.conn = pymysql.connect(host=config['host'],
                                    port=config['port'],
                                    user=config['username'],
                                    passwd=config['password'],
                                    db=config['database'])

    def get_connection(self):
        return self.conn

    def release_connection(self):
        self.conn.close()

    def __del__(self):
        self.conn.close()

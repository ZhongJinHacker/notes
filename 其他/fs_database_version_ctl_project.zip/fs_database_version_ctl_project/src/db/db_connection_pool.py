# -*-coding:utf-8-*-
"""
@author:jiangzhongjin
"""

from src.config.db_config import DbConfig
from src.db.db_connector import DbConnector


class DbConnectionPool:

    __instance = None

    def __new__(cls, *args, **kwargs):
        if cls.__instance is None:
            cls.__instance = super(DbConnectionPool, cls).__new__(cls)
        return cls.__instance

    def __init__(self):
        self._CONNECTION_DICT = {}
        self._dbConfig = DbConfig()

    def __get_connection(self, project_name):
        """
        根据项目名称寻找其数据库连接
        :param project_name:
        :return:
        """
        if project_name in self._CONNECTION_DICT:
            return self._CONNECTION_DICT[project_name]

        config = self._dbConfig.get_config_by(project_name)
        conn = DbConnector(config).get_connection()
        self._CONNECTION_DICT[project_name] = conn
        return conn

    def close_connection(self, project_name):
        """
        关闭连接
        :param project_name:
        :return:
        """
        conn = self._CONNECTION_DICT[project_name]
        conn.close()
        self._CONNECTION_DICT.pop(project_name)

    def execute_sql_list(self, project_name, sql_list):
        """
        执行sql
        :param project_name:
        :param sql_list:
        :return:
        """
        conn = self.__get_connection(project_name)
        try:
            conn.ping()
            cursor = conn.cursor()
            for sql in sql_list:
                cursor.execute(sql)
        except Exception as e:
            conn.rollback()
            print(e)
            print('执行失败sql: %s' % sql)
            raise Exception('执行失败sql: %s : %s' % (project_name, sql))
        finally:
            conn.commit()
            # 关闭mysql连接
            cursor.close()

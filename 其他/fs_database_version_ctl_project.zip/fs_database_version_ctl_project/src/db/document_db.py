# -*-coding:utf-8-*-
"""
@author:jiangzhongjin
"""
import os

from src.constant.path_constant import RESOURCE_VERSION_PATH


class DocumentDb:

    def is_exist_version_file(self):
        """
        检查 版本文件是否存在
        :return:
        """
        return os.path.isfile(RESOURCE_VERSION_PATH)

    def current_version(self):
        """
        获取当前数据库版本
        :return:
        """
        with open(RESOURCE_VERSION_PATH, 'r') as file:
            version = file.readline()
            if len(version) == 0:
                raise Exception('当前数据库版本读取出错')
            return version


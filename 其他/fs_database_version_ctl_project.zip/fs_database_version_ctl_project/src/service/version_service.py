# -*-coding:utf-8-*-
"""
@author:jiangzhongjin
"""
from src.constant.path_constant import RESOURCES_VERSION_DIR_PATH, RESOURCE_VERSION_PATH
from src.db.db_connection_pool import DbConnectionPool
from src.db.document_db import DocumentDb
import os

from src.utils import sql_file_util


class VersionService:

    def __init__(self):
        self._document_db = DocumentDb()

    def checkInitLegal(self):
        """
        检查 执行初始化操作 是否合法
        :return:
        """
        result = self._document_db.is_exist_version_file()
        if result:
            return False
        return True

    def init_db(self, dst_version):
        """
        初始化数据库
        :param dst_version:
        :return:
        """
        # 1. 拿到对应i版本目录下 的文件名列表
        dst_version_dir_path = RESOURCES_VERSION_DIR_PATH + os.sep + dst_version
        dst_init_dir_path = dst_version_dir_path + os.sep + 'init'
        init_project_dir_list = os.listdir(dst_init_dir_path)
        for project_dir in init_project_dir_list:
            init_file_path = dst_init_dir_path + os.sep + project_dir + os.sep + 'init.sql'
            print(init_file_path)
            sql_list = sql_file_util.read_sql_file(init_file_path)
            # 2. 执行对应的sql文件
            DbConnectionPool().execute_sql_list(project_dir, sql_list)

        self.__record_db_version(dst_version)

    def __record_db_version(self, version):
        """
        记录当前数据库表版本
        :param version:
        :return:
        """
        fp = open(RESOURCE_VERSION_PATH, 'w')
        fp.write(version)
        fp.flush()
        fp.close()

    def upgrade(self, dst_version):
        """
        数据库升级
        :param dst_version: 目标版本
        :return:
        """
        result = self._document_db.is_exist_version_file()
        if result:
            version = self._document_db.current_version()
            self.__upgrade_now(version, dst_version)
        else:
            raise Exception('请先执行初始化操作，才可以升级')

    def __upgrade_now(self, cur_version, dst_version):
        upgrade_version_dir_list = []
        tmp_version = cur_version
        while tmp_version < dst_version:
            tmp_version = str(float(tmp_version) + 1.0)
            version_dir = RESOURCES_VERSION_DIR_PATH + os.sep + tmp_version + os.sep + 'update'
            upgrade_version_dir_list.append(version_dir)
            print(os.listdir(version_dir))

        for upgrade_version_dir in upgrade_version_dir_list:
            print("========> " + upgrade_version_dir)
            update_project_dir_list = os.listdir(upgrade_version_dir)
            update_file_path_map = {}
            for project in update_project_dir_list:
                update_file_path_map[project] = upgrade_version_dir + os.sep + project + os.sep + 'update.sql'

            for key in update_file_path_map.keys():
                print('key: ' + key + '  value: ' + update_file_path_map[key])
                sql_list = sql_file_util.read_sql_file(update_file_path_map[key])
                print(sql_list)
                DbConnectionPool().execute_sql_list(key, sql_list)

        self.__record_db_version(dst_version)

    def rollback(self, dst_version):
        """
        回滚到目标版本
        :param dst_version: 目标版本
        :return:
        """
        result = self._document_db.is_exist_version_file()
        if result:
            version = self._document_db.current_version()
            self.__rollback_now(version, dst_version)
        else:
            raise Exception('请先执行初始化操作，才可以回滚')

    def __rollback_now(self, cur_version, dst_version):
        rollback_version_dir_list = []
        tmp_version = cur_version
        while tmp_version > dst_version:
            version_dir = RESOURCES_VERSION_DIR_PATH + os.sep + tmp_version + os.sep + 'rollback'
            rollback_version_dir_list.append(version_dir)
            tmp_version = str(float(tmp_version) - 1.0)

        for rollback_version_dir in rollback_version_dir_list:
            rollback_project_dir_list = os.listdir(rollback_version_dir)
            rollback_file_path_map = {}
            for project in rollback_project_dir_list:
                rollback_file_path_map[project] = rollback_version_dir + os.sep + project + os.sep + 'rollback.sql'

            for key in rollback_file_path_map.keys():
                print('key: ' + key + '  value: ' + rollback_file_path_map[key])
                sql_list = sql_file_util.read_sql_file(rollback_file_path_map[key])
                print(sql_list)
                DbConnectionPool().execute_sql_list(key, sql_list)

        self.__record_db_version(dst_version)

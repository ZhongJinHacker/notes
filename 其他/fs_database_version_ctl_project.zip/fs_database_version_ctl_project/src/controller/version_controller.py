# -*-coding:utf-8-*-
"""
@author:jiangzhongjin
"""
from src.service.version_service import VersionService


class VersionController:
    """
    版本管理控制器
    """

    def __init__(self):
        self._version_service = VersionService()

    def init(self, dst_version: str):
        """
        初始化数据库到 dst_version 版本
        :param dst_version: 目标版本
        :return:
        """
        if self._version_service.checkInitLegal():
            self._version_service.init_db(dst_version)
        else:
            return {'result': False, 'msg': '数据库已初始化过，请走升级流程'}

    def upgrade(self, dst_version: str):
        """
        从 from_version 版本升级到 dst_version
        :param dst_version:
        :return:
        """
        self._version_service.upgrade(dst_version)



    def rollback(self, dst_version: str):
        """
        从 from_version 版本回滚到 dst_version
        :param dst_version:
        :return:
        """
        self._version_service.rollback(dst_version)

# -*-coding:utf-8-*-
"""
@author:jiangzhongjin
"""
import json


from src.constant.path_constant import DB_CONFIG_PATH


class DbConfig:
    """
    数据库配置类
    """

    def __init__(self):
        with open(DB_CONFIG_PATH, 'r') as f:
            self.json_config = json.load(f)

    def fs_base_openmics_config(self):
        """
        获取 fs_base_openmics 数据库连接配置
        :return:
        """
        return self.json_config['fs_base_openmics']

    def fs_base_uc_config(self):
        """
        获取 fs_base_uc 数据库连接配置
        :return:
        """
        return self.json_config['fs_base_uc']

    def get_config_by(self, project_name):
        """
        根据项目名称取它对应的数据库配置
        :param project_name:
        :return:
        """
        return self.json_config[project_name]

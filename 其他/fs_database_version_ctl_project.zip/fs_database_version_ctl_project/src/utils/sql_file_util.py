# -*-coding:utf-8-*-
"""
@author:jiangzhongjin
"""


def read_sql_file(sql_file_path):
    with open(sql_file_path, encoding="utf-8", mode='r') as f:
        ret_sql_list = []
        # 读取整个sql文件，以分号切割。[:-1]删除最后一个元素，也就是空字符串
        sql_list = f.read().split(';')[:-1]
        print('------------------------------------------')
        for x in sql_list:
            # 判断包含空行的
            if '\n' in x:
                # 替换空行为1个空格
                x = x.replace('\n', ' ')

            # 判断多个空格时
            if '    ' in x:
                # 替换为空
                x = x.replace('    ', '')

            # sql语句添加分号结尾
            sql_item = x + ';'
            print('整理后的sql: ' + sql_item)
            ret_sql_list.append(sql_item)

        return ret_sql_list

# -*-coding:utf-8-*-
"""
@author:jiangzhongjin
"""
import sys
import re

from src.controller.version_controller import VersionController

CMD_INIT = '--init'
CMD_UPGRADE = '--upgrade'
CMD_ROLLBACK = '--rollback'


class OptionView:

    def __init__(self):
        self.__view_controller = VersionController()

    def usage(self):
        """
        使用方法
        :return:
        """
        usage_str = """
        The usage of the commands:
        --init version_code     e.g. --init 1.0
        --upgrade version_code  e.g. --upgrade 3.0
        --rollback version_code e.g. --rollback 2.0
        """
        print(usage_str)

    def action(self):
        """
        执行
        :return:
        """
        option_len = len(sys.argv)
        if option_len == 3:
            self.__action_now(sys.argv[1], sys.argv[2])
        else:
            self.usage()

    def __action_now(self, cmd_option, version_code):
        if not self.check_version_code(version_code):
            print('version code 非法：' + version_code)
            self.usage()
            return
        if cmd_option == CMD_INIT:
            self.__view_controller.init(version_code)
        elif cmd_option == CMD_UPGRADE:
            self.__view_controller.upgrade(version_code)
        elif cmd_option == CMD_ROLLBACK:
            self.__view_controller.rollback(version_code)
        else:
            self.usage()

    def check_version_code(self, version_code):
        re_compile = re.compile(r"""^[0-9]+\.[0-9]+$""")
        result = re_compile.search(version_code)
        return bool(result)

from unittest import TestCase

from src.config.db_config import DbConfig


class TestDbConfig(TestCase):

    def test_fs_base_openmics_config(self):
        db_config_obj = DbConfig()
        fs_base_openmics_config = db_config_obj.fs_base_openmics_config()
        print(fs_base_openmics_config)

    def test_fs_base_uc_config(self):
        db_config_obj = DbConfig()
        fs_base_uc_config = db_config_obj.fs_base_uc_config()
        print('==>' + str(fs_base_uc_config))

    def test_get_config_by(self):
        db_config_obj = DbConfig()
        config = db_config_obj.get_config_by('fs_base_uc')
        print(config)

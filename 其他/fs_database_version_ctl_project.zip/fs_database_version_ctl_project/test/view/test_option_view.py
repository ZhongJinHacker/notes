# -*-coding:utf-8-*-
"""
@author:jiangzhongjin
"""
from unittest import TestCase

from src.view.option_view import OptionView


class TestOptionView(TestCase):

    def test_usage(self):
        option_view = OptionView()
        option_view.usage()

    def test_check_version_code(self):
        option_view = OptionView()
        result = option_view.check_version_code('22.0')
        print(result)

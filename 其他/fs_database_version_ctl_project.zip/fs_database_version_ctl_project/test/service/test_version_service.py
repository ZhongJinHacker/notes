# -*-coding:utf-8-*-
"""
@author:jiangzhongjin
"""
from unittest import TestCase

from src.service.version_service import VersionService


class TestVersionService(TestCase):

    def test_init_db(self):
        version_service = VersionService()
        version_service.init_db('1.0')
        print('----------')
        version_service.init_db('4.0')

    def test_upgrade(self):
        version_service = VersionService()
        version_service.upgrade('4.0')

    def test_rollback(self):
        version_service = VersionService()
        version_service.rollback('1.0')

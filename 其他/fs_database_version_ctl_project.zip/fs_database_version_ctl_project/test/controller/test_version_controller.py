# -*-coding:utf-8-*-
"""
@author:jiangzhongjin
"""
from unittest import TestCase

from src.controller.version_controller import VersionController


class TestVersionController(TestCase):

    def test_init(self):
        version_controller = VersionController()
        version_controller.init('1.0')

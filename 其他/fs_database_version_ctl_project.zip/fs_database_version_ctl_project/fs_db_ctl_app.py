# -*-coding:utf-8-*-
"""
@author:jiangzhongjin
"""
from src.view.option_view import OptionView

if __name__ == '__main__':
    option_view = OptionView()
    option_view.action()

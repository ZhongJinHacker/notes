# -*-coding:utf-8-*-
"""
@author:jiangzhongjin
"""
from unittest import TestCase
from fsbaseuc_database import fsbaseucDatabase


class TestFsbaseucDatabase(TestCase):

    def test_get_user_id(self):
        ret = fsbaseucDatabase.get_user_id(1001, '0000011')
        print(ret)

    def test_fiter(self):
        d_list = ["hello", "1", "world", "1", "......."]
        print(d_list)
        for d in d_list:
            if d == "1":
                d_list.remove(d)

        print(d_list)

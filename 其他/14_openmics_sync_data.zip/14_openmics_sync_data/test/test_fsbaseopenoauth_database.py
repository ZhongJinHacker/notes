# -*-coding:utf-8-*-
"""
@author:jiangzhongjin
"""
from unittest import TestCase
from fsbaseopenoauth_database import fsbaseopenoauthDatabase, create_client_model
import tools


class TestFsbaseopenoauthDatabase(TestCase):
    def test_insert_client(self):
        app_id = secret = tools.create_uuid()
        print(app_id)
        print(secret)
        model = create_client_model(app_id, secret, 1001)
        fsbaseopenoauthDatabase.insert_client(model)
        print()
# -*-coding:utf-8-*-
"""
@author:jiangzhongjin
"""
from unittest import TestCase
from fsbasemics_database import fsbasemicsDatabase
from tools import create_uuid
from cert_service import cert_service


class TestFsbasemicsDatabase(TestCase):

    def test_query_mics_rbac_sys_user(self):
        dst_user_dict_list = fsbasemicsDatabase.query_mics_rbac_sys_user()
        print(dst_user_dict_list)

    def test_insert_into_mics_rbac_company_user(self):
        model = {
            "company_id": "1111",
            "user_id": "11011",
            "account": "11111",
            "user_name": "11111",
            "introduce": "11111",
            "status": "1",
            "reason": ""
        }
        dst_user_dict_list = [model]
        fsbasemicsDatabase.insert_into_mics_rbac_company_user(dst_user_dict_list)
        print()

    def test_query_app_manager_user(self):
        list = fsbasemicsDatabase.query_app_manager_user()
        print(list)
        model = list[0]
        app_id = create_uuid()
        secret = create_uuid()
        model["app_id"] = app_id
        model["secret"] = secret
        insert_id = fsbasemicsDatabase.insert_into_mics_rbac_certificate(model)
        fsbasemicsDatabase.insert_into_mics_rbac_certificate_resource(model, insert_id)

    def test_query_report_manager_user(self):
        list = fsbasemicsDatabase.query_report_manager_user()
        print(list)
        model = list[0]
        app_id = create_uuid()
        secret = create_uuid()
        model["app_id"] = app_id
        model["secret"] = secret
        insert_id = fsbasemicsDatabase.insert_into_mics_rbac_certificate(model)
        fsbasemicsDatabase.insert_into_mics_rbac_certificate_resource(model, insert_id)

    def test_manager_one(self):
        list = fsbasemicsDatabase.query_report_manager_user()
        cert_service.handle_developer_cert(list)

    def test_mate_one(self):
        report_normal_user_list = fsbasemicsDatabase.query_report_normal_user()
        print(str(len(report_normal_user_list)))
        cert_service.handle_dev_mate_cert(report_normal_user_list)